from setuptools import setup                #para hacer redistribuible el pauqete yque otra persona lo pueda instalar


setup (
    name="mipaquete",
    version=1.0,
    description="mi perimer paquete de python", 
    author="Paula",
    packages=['paquete'], # puedo hacer una lista d elos paquetes que quiero incluir

)