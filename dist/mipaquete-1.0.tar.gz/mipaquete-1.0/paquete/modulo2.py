def funcion_modulo2():
    print ("Hola estoy en mi paquete modulo 2")
    