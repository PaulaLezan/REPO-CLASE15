def funcionpaquete():
    print("Estoy en mi paquete")
    
